<h3 class="page-header">Tambah admin Baru</h3>
<?php 
              if (isset($_GET['st'])) {
                if ($_GET['st']==1) {
                  echo "<div class='alert alert-warning'><strong>Berhasil Ditambahkan.</strong></div>";
                } elseif ($_GET['st']==2) {
                  echo "<div class='alert alert-danger'><strong>Gagal Menambahkan.</strong></div>";
                } elseif ($_GET['st']==3) {
                  echo "<div class='alert alert-danger'><strong>Maaf Email sudah digunakan.</strong></div>";
                } elseif ($_GET['st']==4) {
                  echo "<div class='alert alert-danger'><strong>Kolom tidak boleh kosong.</strong></div>";
                }
              }

             ?>
			 <form class="form-horizontal" role="form" style="width:80%" method="post" action="./root/proses.php">
              <div class="form-group">
                <label class="control-label col-sm-2" for="name">Nama Lengkap:</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama" placeholder="Masukan Nama Lengkap" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2">Password:</label>
                <div class="col-sm-10"> 
                  <input type="password" class="form-control" name="pwd" placeholder="Enter password" required>
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-default" name="add_pbXia1Zasww12Q">Submit</button>
                </div>
              </div>
            </form>