<?php 
    /**
	 *
     * Open Source SMK Walisongo Semarnag
     *  
     */
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpwd = "";
    $dbname = "absensi";

    $conn = new mysqli($dbhost, $dbuser, $dbpwd, $dbname);
 ?>
