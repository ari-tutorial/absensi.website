<?php
    /**
     * 
     *  
     */
	echo "<script>window.alert('Waaahh.. Bandel ya !! ');window.location=('../home');</script>"; 
?>